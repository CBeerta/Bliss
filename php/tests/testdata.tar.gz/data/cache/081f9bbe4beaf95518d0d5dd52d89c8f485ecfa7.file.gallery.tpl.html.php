<?php /* Smarty version Smarty-3.1-DEV, created on 2013-08-18 12:31:05
         compiled from "/home/claus/www/Bliss/php/views/gallery.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:5489800555210be897c79f2-68623207%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '081f9bbe4beaf95518d0d5dd52d89c8f485ecfa7' => 
    array (
      0 => '/home/claus/www/Bliss/php/views/gallery.tpl.html',
      1 => 1368474451,
      2 => 'file',
    ),
    'ac1eef747898f1571233809e69a9d548e913679c' => 
    array (
      0 => '/home/claus/www/Bliss/php/views/layout.tpl.html',
      1 => 1376814972,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5489800555210be897c79f2-68623207',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'title' => 0,
    'demo_install' => 0,
    'base_uri' => 0,
    'enable_gallery' => 0,
    'bliss_version' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_5210be8983ab04_85158623',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5210be8983ab04_85158623')) {function content_5210be8983ab04_85158623($_smarty_tpl) {?><!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8"/>
        <title>Bliss<?php if (isset($_smarty_tpl->tpl_vars['title']->value)){?> - <?php echo $_smarty_tpl->tpl_vars['title']->value;?>
<?php }?></title>
        <meta name="description" content=""/>
        <link rel="shortcut icon" href="favicon.png" type="image/png"/>
        <link rel="stylesheet" href="public/styles/reset.css" media="all"/>
        <link rel="stylesheet" href="public/styles/all.css" media="all"/>
        <link rel="stylesheet" href="public/styles/print.css" media="print"/>

<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
public/scripts/fancybox/jquery.fancybox.compressed-1.3.4.css">

        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Maven+Pro:regular,bold,italic,bolditalic" type="text/css">
        <script src="public/scripts/modernizr-1.7.min.js"></script>
    </head>
    <body>
<?php if (isset($_smarty_tpl->tpl_vars['demo_install']->value)){?>
        <a href="http://github.com/CBeerta">
            <img style="position: fixed; top: 0; right: 0; border: 0;" src="https://d3nwyuy0nl342s.cloudfront.net/img/7afbc8b248c68eb468279e8c17986ad46549fb71/687474703a2f2f73332e616d617a6f6e6177732e636f6d2f6769746875622f726962626f6e732f666f726b6d655f72696768745f6461726b626c75655f3132313632312e706e67" alt="Fork me on GitHub">
        </a>
<?php }?>
        <div class="pulldown">
            <div id="options">
            <form method="POST" action="add_feed">
                <input id="add_feed" type="url" size="40" name="add" placeholder="Add a new Feed">
                <input type="submit" value="Go!">
            </form>
            </div>
            <div id="lip">
            <a href="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
#select-unread-articles">
                <img id="unread-articles" title="Unread Articles" src="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
public/fire.png" width="32" height="32" />
            </a>
            <a href="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
#select-all-articles">
                <img id="load-articles" title="All Articles" src="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
public/house.png" width="32" height="32" />
            </a>
            <a href="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
#select-day-today">
                <img id="select-day" title="Todays Articles" src="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
public/date_magnify.png" width="32" height="32" />
            </a>
            <a href="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
#select-flagged-articles">
                <img id="load-articles" title="Flagged Articles" src="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
public/tag_blue.png" width="32" height="32" />
            </a>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <a href="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
archive">
                <img id="archive" title="Archive" src="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
public/directory_listing.png" width="32" height="32" />
            </a>
<?php if (isset($_smarty_tpl->tpl_vars['enable_gallery']->value)){?>
            <a href="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
gallery">
                <img id="gallery" title="Image Gallery" src="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
public/images.png" width="32" height="32" />
            </a>
<?php }?>
            &nbsp;&nbsp;&nbsp;&nbsp;
            <img id="handle" title="Add Feed" src="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
public/feed_add.png" width="32" height="32" />
            <a href="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
manage">
                <img id="manage" title="Manage Subscriptions" src="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
public/feed_edit.png" width="32" height="32" />
            </a>
            </div>
            <p id="logo">Bliss</p>
            <img src="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
public/emotion_happy.png" width="32" height="32" id="logo" title="Happy Place!"/>
        </div>
        <img id="spinner" src="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
public/indicator.gif" />
        <div class="updater">
            <img src="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
public/update.png" width="32" height="32">
            New Articles Available!
        </div>
        <div class="feedback"></div>
        <div id="main" role="main">

<div id="content" class="gallery"></div>
<div class="clearfix"></div>

        </div>        
        <footer>
        <!-- this footer is important leave it intact, otherwise the initial load will fail -->
        Bliss <?php echo $_smarty_tpl->tpl_vars['bliss_version']->value;?>
 &copy; 2011 <a href="http://claus.beerta.net/">Claus Beerta</a> <a href="mailto:claus@beerta.de">&lt;claus@beerta.de&gt;</a>
        </footer>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script>
        <script src="public/scripts/all.js"></script>
        <!--[if lt IE 9 ]>
        <script src="//ajax.googleapis.com/ajax/libs/chrome-frame/1.0.2/CFInstall.min.js"></script>
        <script>window.attachEvent("onload",function() { CFInstall.check( { mode:"overlay" } ) } )</script>
        <![endif]-->

<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
public/scripts/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
<script type="text/javascript" src="<?php echo $_smarty_tpl->tpl_vars['base_uri']->value;?>
public/scripts/gallery.js"></script>

    </body>
</html>
<?php }} ?>