<?php /* Smarty version Smarty-3.1-DEV, created on 2013-08-18 15:26:00
         compiled from "/home/claus/www/Bliss/php/views/plugins/enclosures.tpl.html" */ ?>
<?php /*%%SmartyHeaderCode:20334923355210e7889a9029-85071346%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '62122cd5791ee831136db53b1af56ff0133b3bbc' => 
    array (
      0 => '/home/claus/www/Bliss/php/views/plugins/enclosures.tpl.html',
      1 => 1376827546,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20334923355210e7889a9029-85071346',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'item' => 0,
    'enclosure' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1-DEV',
  'unifunc' => 'content_5210e788a1f2d1_26112693',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5210e788a1f2d1_26112693')) {function content_5210e788a1f2d1_26112693($_smarty_tpl) {?><?php  $_smarty_tpl->tpl_vars['enclosure'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['enclosure']->_loop = false;
 $_from = $_smarty_tpl->tpl_vars['item']->value->enclosures; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
 $_smarty_tpl->tpl_vars['enclosure']->total= $_smarty_tpl->_count($_from);
 $_smarty_tpl->tpl_vars['enclosure']->iteration=0;
 $_smarty_tpl->tpl_vars['enclosure']->index=-1;
foreach ($_from as $_smarty_tpl->tpl_vars['enclosure']->key => $_smarty_tpl->tpl_vars['enclosure']->value){
$_smarty_tpl->tpl_vars['enclosure']->_loop = true;
 $_smarty_tpl->tpl_vars['enclosure']->iteration++;
 $_smarty_tpl->tpl_vars['enclosure']->index++;
 $_smarty_tpl->tpl_vars['enclosure']->first = $_smarty_tpl->tpl_vars['enclosure']->index === 0;
 $_smarty_tpl->tpl_vars['enclosure']->last = $_smarty_tpl->tpl_vars['enclosure']->iteration === $_smarty_tpl->tpl_vars['enclosure']->total;
?>
<?php if ($_smarty_tpl->tpl_vars['enclosure']->first){?>
<div class="enclosures">
<h1>Attachements:</h1>
<p>
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['enclosure']->value['medium']=='image'){?>
<a class="fancyme" href="<?php echo $_smarty_tpl->tpl_vars['enclosure']->value['image_url'];?>
">
<img src="<?php echo $_smarty_tpl->tpl_vars['enclosure']->value['image_url'];?>
" width="64" name="<?php echo $_smarty_tpl->tpl_vars['enclosure']->value['title'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['enclosure']->value['title'];?>
">
</a>
<?php }else{ ?>
<a href="<?php echo $_smarty_tpl->tpl_vars['enclosure']->value['link'];?>
">
<img src="public/mime_images/<?php echo $_smarty_tpl->tpl_vars['enclosure']->value['medium'];?>
.png" width="32" height="32" name="<?php echo $_smarty_tpl->tpl_vars['enclosure']->value['title'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['enclosure']->value['title'];?>
">
</a>
<?php }?>
<?php if ($_smarty_tpl->tpl_vars['enclosure']->last){?>
</p>
</div>
<?php }?>
<?php } ?>
<?php }} ?>